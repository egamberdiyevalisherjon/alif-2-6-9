import Link from "./Components/Link";

function App() {
  return (
    <div className="App">
      <Link
        arr={''}
        // className="text-dark"
        // link="https://bitgansayt.web.app"
        blank
      >
        Sayt
      </Link>{" "}
      Saytimiz bitti va TUGADI!!! + Firebase qoshildi
    </div>
  );
}

export default App;
