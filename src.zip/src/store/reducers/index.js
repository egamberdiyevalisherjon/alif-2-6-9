import rootReducer from "./rootReducer";

export default rootReducer;
